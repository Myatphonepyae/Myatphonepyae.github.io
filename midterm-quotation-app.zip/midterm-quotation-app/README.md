# WAD 2024 Midterm Skeleton Code

This is the skeleton code for the WAD Midterm. Get the project code using one of these methods:
1. **Git Clone:** Unfortunately, we have not covered this in the class yet.
2. **Download:** Download the zip file and extract it.

# Setup
1. Change directory to the project folder
```bash
cd wad-midterm-skeleton
```
2. Install dependencies
```bash
pnpm install
```
3. Start the development server
```bash
pnpm run dev
```